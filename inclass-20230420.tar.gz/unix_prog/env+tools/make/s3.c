
int s3() {
	return 3;
}

