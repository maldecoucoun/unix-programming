#!/bin/sh

# run  sh testret.sh
# (or) sh -e testret.sh

echo 0
./return 0
echo 1
./return 1
echo 2
./return 2


