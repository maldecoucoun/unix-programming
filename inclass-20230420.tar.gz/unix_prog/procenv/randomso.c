int rand(void) {
	return 1234;
}
