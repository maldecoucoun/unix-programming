
#define	b	_Z1bv

int b();

int main() {
	b();
}

