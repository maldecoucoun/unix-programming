
int s2() {
	return 2;
}

