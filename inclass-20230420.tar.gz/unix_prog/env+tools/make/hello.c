#include <stdio.h>

int s1();
int s2();
int s3();

int main() {
	printf("hello %d %d %d\n", s1(), s2(), s3());
	return 0;
}

